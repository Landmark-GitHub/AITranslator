import sys
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QStackedWidget, QFileDialog, QLineEdit, QTextEdit,
    QComboBox, QProgressBar, QTableWidget, QTableWidgetItem, QHeaderView,
    QMessageBox, QSplitter, QCheckBox
)

APP_STYLE = """
QMainWindow, QWidget { background: #10131b; color: #e8ecf5; font-family: Segoe UI; font-size: 10pt; }
QFrame#sidebar { background: #171c28; border-right: 1px solid #2a3142; }
QFrame#panel { background: #191f2c; border: 1px solid #2b3447; border-radius: 12px; }
QLabel#muted { color: #9aa6bb; }
QLabel#title { font-size: 22pt; font-weight: 700; }
QLabel#section { font-size: 13pt; font-weight: 650; }
QPushButton { background: #293348; border: 1px solid #394761; border-radius: 8px; padding: 9px 13px; color: #f4f6fb; }
QPushButton:hover { background: #35435e; }
QPushButton#primary { background: #7257e8; border: 1px solid #8a75f0; font-weight: 650; }
QPushButton#primary:hover { background: #826cf0; }
QPushButton#nav { text-align: left; padding: 12px; background: transparent; border: 0; color: #bac4d6; }
QPushButton#nav:checked { background: #292445; color: #ffffff; border-left: 3px solid #9b87ff; }
QLineEdit, QTextEdit, QComboBox { background: #111722; border: 1px solid #354056; border-radius: 7px; padding: 8px; color: #edf1f8; }
QTableWidget { background: #111722; alternate-background-color: #171e2b; gridline-color: #30394c; border: 1px solid #30394c; border-radius: 8px; }
QHeaderView::section { background: #242d3e; color: #cbd5e5; padding: 8px; border: 0; }
QProgressBar { background: #252d3c; border: 0; border-radius: 5px; height: 10px; text-align: center; }
QProgressBar::chunk { background: #8b75f3; border-radius: 5px; }
QCheckBox { spacing: 8px; }
"""

def label(text, name=None):
    w = QLabel(text)
    if name:
        w.setObjectName(name)
    return w

def panel(title, subtitle=None):
    f = QFrame()
    f.setObjectName("panel")
    l = QVBoxLayout(f)
    l.setContentsMargins(16, 14, 16, 16)
    l.setSpacing(9)
    l.addWidget(label(title, "section"))
    if subtitle:
        l.addWidget(label(subtitle, "muted"))
    return f, l

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AI Video Translator Studio — Prototype")
        self.resize(1280, 820)
        root = QWidget()
        self.setCentralWidget(root)
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        side = QFrame()
        side.setObjectName("sidebar")
        side.setFixedWidth(230)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(16, 22, 16, 18)
        sl.setSpacing(8)
        sl.addWidget(label("◈  AI VIDEO STUDIO"))
        sl.addWidget(label("TRANSLATE  •  DUB  •  EXPORT", "muted"))
        sl.addSpacing(22)

        self.stack = QStackedWidget()
        self.nav_buttons = []
        pages = [
            ("01  โปรเจกต์ / นำเข้าคลิป", self.build_project),
            ("02  วิเคราะห์เสียงและซับ", self.build_analysis),
            ("03  แปลภาษาไทย", self.build_translation),
            ("04  เสียงพากย์และ Timeline", self.build_dubbing),
            ("05  ส่งออกวิดีโอ", self.build_export),
            ("06  Demo EN / JP", self.build_demo),
        ]
        for i, (name, builder) in enumerate(pages):
            b = QPushButton(name)
            b.setObjectName("nav")
            b.setCheckable(True)
            b.clicked.connect(lambda checked=False, idx=i: self.navigate(idx))
            sl.addWidget(b)
            self.nav_buttons.append(b)
            self.stack.addWidget(builder())
        sl.addStretch()
        sl.addWidget(label("Prototype v0.1 • UI flow only", "muted"))
        outer.addWidget(side)
        outer.addWidget(self.stack, 1)
        self.navigate(0)

    def navigate(self, idx):
        self.stack.setCurrentIndex(idx)
        for i, b in enumerate(self.nav_buttons):
            b.setChecked(i == idx)

    def page_shell(self, eyebrow, title, desc):
        w = QWidget()
        l = QVBoxLayout(w)
        l.setContentsMargins(28, 24, 28, 24)
        l.setSpacing(16)
        l.addWidget(label(eyebrow.upper(), "muted"))
        l.addWidget(label(title, "title"))
        l.addWidget(label(desc, "muted"))
        return w, l

    def build_project(self):
        w, l = self.page_shell("Workspace / Source", "นำเข้าวิดีโอ", "รองรับคลิปที่มีซับและไม่มีซับ • ต้นแบบการทำงานแบบ Hybrid (Local + Cloud)")
        row = QHBoxLayout()
        left, ll = panel("ไฟล์ต้นฉบับ", "เลือกวิดีโอหรือไฟล์ซับแยก")
        self.file_path = QLineEdit()
        self.file_path.setPlaceholderText("ยังไม่ได้เลือกไฟล์วิดีโอ…")
        browse = QPushButton("เลือกวิดีโอ")
        browse.setObjectName("primary")
        browse.clicked.connect(self.pick_video)
        ll.addWidget(self.file_path)
        ll.addWidget(browse)
        self.subtitle_path = QLineEdit()
        self.subtitle_path.setPlaceholderText("ไฟล์ซับ SRT / ASS (ถ้ามี)")
        sub_btn = QPushButton("เลือกไฟล์ซับ")
        sub_btn.clicked.connect(self.pick_subtitle)
        ll.addWidget(self.subtitle_path)
        ll.addWidget(sub_btn)
        right, rl = panel("การตั้งค่าโปรเจกต์")
        self.source_lang = QComboBox()
        self.source_lang.addItems(["ตรวจจับภาษาอัตโนมัติ", "English", "Japanese"])
        self.input_type = QComboBox()
        self.input_type.addItems(["ตรวจจับอัตโนมัติ (มีซับ / ไม่มีซับ)", "มีซับฝังในภาพ", "มีไฟล์ซับแยก", "ไม่มีซับ"])
        self.output_lang = QComboBox()
        self.output_lang.addItems(["ภาษาไทย"])
        rl.addWidget(label("ภาษาต้นฉบับ", "muted")); rl.addWidget(self.source_lang)
        rl.addWidget(label("รูปแบบซับ", "muted")); rl.addWidget(self.input_type)
        rl.addWidget(label("ภาษาเป้าหมาย", "muted")); rl.addWidget(self.output_lang)
        row.addWidget(left, 3); row.addWidget(right, 2)
        l.addLayout(row)
        info, il = panel("Workflow ที่จะทำงาน")
        il.addWidget(label("ตรวจจับคำพูด → อ่าน/สร้างซับ → วิเคราะห์ผู้พูดและอารมณ์ → แปลไทย → สร้างเสียงพากย์ → Sync → Render"))
        l.addWidget(info)
        actions = QHBoxLayout()
        actions.addStretch()
        go = QPushButton("เริ่มวิเคราะห์  →"); go.setObjectName("primary")
        go.clicked.connect(lambda: self.navigate(1))
        actions.addWidget(go)
        l.addLayout(actions)
        l.addStretch()
        return w

    def pick_video(self):
        p, _ = QFileDialog.getOpenFileName(self, "เลือกวิดีโอ", "", "Video (*.mp4 *.mkv *.mov *.avi *.webm)")
        if p: self.file_path.setText(p)

    def pick_subtitle(self):
        p, _ = QFileDialog.getOpenFileName(self, "เลือกไฟล์ซับ", "", "Subtitles (*.srt *.ass *.ssa *.vtt)")
        if p: self.subtitle_path.setText(p)

    def build_analysis(self):
        w, l = self.page_shell("Analysis / Quality Check", "วิเคราะห์คำพูดและซับ", "ตรวจสอบความสอดคล้องระหว่างเสียงพูด ข้อความซับ ผู้พูด และอารมณ์")
        top = QHBoxLayout()
        p1, a = panel("ผลตรวจจับคลิป", "ตัวอย่างข้อมูลสำหรับ Prototype")
        a.addWidget(label("ภาษา: English / Japanese (Auto detect)"))
        a.addWidget(label("เสียงพูด: พบ 2 ผู้พูด"))
        a.addWidget(label("ซับ: ตรวจพบข้อความ 18 ช่วง"))
        a.addWidget(label("คุณภาพเสียง: พร้อมวิเคราะห์"))
        p2, b = panel("การวิเคราะห์น้ำเสียง", "วิเคราะห์แยกตามช่วงประโยค")
        b.addWidget(label("Speaker 01  •  โทนจริงจัง  •  ความเร็วปานกลาง"))
        b.addWidget(label("Speaker 02  •  โทนตื่นเต้น  •  พูดเร็ว"))
        b.addWidget(label("หมายเหตุ: อารมณ์เป็นค่าประเมินจากโมเดล ไม่ใช่ข้อเท็จจริงแน่นอน"))
        top.addWidget(p1); top.addWidget(p2)
        l.addLayout(top)
        p, pl = panel("ตารางตรวจสอบคำพูด / ซับ")
        table = QTableWidget(4, 5)
        table.setHorizontalHeaderLabels(["เวลา", "ผู้พูด", "เสียงที่ตรวจจับ", "ซับที่อ่านได้", "สถานะ"])
        rows = [
            ["00:00:01.2", "Speaker 01", "What are you doing?", "What are you doing?", "ตรงกัน"],
            ["00:00:03.8", "Speaker 02", "Don't come closer!", "Don't come closer!", "ตรงกัน"],
            ["00:00:06.1", "Speaker 01", "I will protect you.", "I protect you.", "ควรตรวจสอบ"],
            ["00:00:09.4", "Speaker 02", "Please wait!", "—", "ไม่มีซับ"],
        ]
        for r, row in enumerate(rows):
            for c, val in enumerate(row): table.setItem(r, c, QTableWidgetItem(val))
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setAlternatingRowColors(True)
        pl.addWidget(table)
        l.addWidget(p, 1)
        btns = QHBoxLayout(); btns.addStretch()
        nxt = QPushButton("ไปหน้าแปลภาษา  →"); nxt.setObjectName("primary"); nxt.clicked.connect(lambda: self.navigate(2))
        btns.addWidget(nxt); l.addLayout(btns)
        return w

    def build_translation(self):
        w, l = self.page_shell("Translation / Review", "แปลภาษาไทย", "แก้ไขคำแปลได้ก่อนสร้างเสียงพากย์ • รักษาความหมายและบริบทของบทสนทนา")
        p, pl = panel("รายการแปล", "ตัวอย่างประโยคจาก Demo")
        table = QTableWidget(4, 4)
        table.setHorizontalHeaderLabels(["เวลา", "ผู้พูด", "ต้นฉบับ", "คำแปลไทย (แก้ไขได้)"])
        rows = [
            ["00:01–00:03", "Speaker 01", "What are you doing?", "คุณกำลังทำอะไรอยู่?"],
            ["00:03–00:05", "Speaker 02", "Don't come closer!", "อย่าเข้ามานะ!"],
            ["00:06–00:08", "Speaker 01", "I will protect you.", "ฉันจะปกป้องเธอเอง"],
            ["00:09–00:10", "Speaker 02", "Please wait!", "รอก่อน!"],
        ]
        for r, row in enumerate(rows):
            for c, val in enumerate(row): table.setItem(r, c, QTableWidgetItem(val))
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setAlternatingRowColors(True)
        pl.addWidget(table)
        l.addWidget(p, 1)
        p2, p2l = panel("แนวทางการแปล")
        opts = QHBoxLayout()
        self.style = QComboBox(); self.style.addItems(["เป็นธรรมชาติ / บทสนทนา", "แปลตรงต้นฉบับ", "สไตล์ภาพยนตร์ / อนิเมะ"])
        self.formality = QComboBox(); self.formality.addItems(["ภาษาพูดทั่วไป", "สุภาพ", "กันเอง"])
        opts.addWidget(label("สไตล์")); opts.addWidget(self.style); opts.addWidget(label("ระดับภาษา")); opts.addWidget(self.formality)
        p2l.addLayout(opts); l.addWidget(p2)
        btns = QHBoxLayout(); btns.addStretch()
        nxt = QPushButton("ตั้งค่าเสียงพากย์  →"); nxt.setObjectName("primary"); nxt.clicked.connect(lambda: self.navigate(3))
        btns.addWidget(nxt); l.addLayout(btns)
        return w

    def build_dubbing(self):
        w, l = self.page_shell("Voice / Synchronization", "เสียงพากย์และ Timeline", "เลือกเสียงไทยที่มีโทนใกล้เคียงต้นฉบับ โดยไม่โคลนเสียงบุคคลอัตโนมัติ")
        row = QHBoxLayout()
        p, pl = panel("โปรไฟล์เสียงพากย์", "Voice matching")
        self.voice_type = QComboBox(); self.voice_type.addItems(["เสียงไทยโทนใกล้เคียงต้นฉบับ", "เสียงหญิงวัยผู้ใหญ่", "เสียงชายวัยผู้ใหญ่", "เสียงวัยรุ่น", "กำหนดเสียงเอง"])
        self.emotion = QComboBox(); self.emotion.addItems(["รักษาอารมณ์จากต้นฉบับ", "จริงจัง", "ตื่นเต้น", "เศร้า", "โกรธ", "เป็นกลาง"])
        self.speed = QComboBox(); self.speed.addItems(["ปรับอัตโนมัติตามช่วงเวลา", "ช้าลงเล็กน้อย", "ความเร็วปกติ", "เร็วขึ้นเล็กน้อย"])
        for t, widget in [("รูปแบบเสียง", self.voice_type), ("อารมณ์", self.emotion), ("ความเร็ว", self.speed)]:
            pl.addWidget(label(t, "muted")); pl.addWidget(widget)
        p2, p2l = panel("การ Sync เสียง")
        p2l.addWidget(label("☑ จัดเสียงตาม timestamp ของประโยค"))
        p2l.addWidget(label("☑ ปรับความเร็วเสียงเมื่อยาวเกินช่วง"))
        p2l.addWidget(label("☑ เว้นจังหวะหายใจและช่องว่างระหว่างประโยค"))
        p2l.addWidget(label("☐ สร้างเสียงเลียนแบบบุคคลจริง (ต้องมีสิทธิ์และการยินยอม)"))
        p2l.addWidget(label("สถานะ Timeline: ยังไม่ได้สร้างเสียงจริง", "muted"))
        row.addWidget(p, 1); row.addWidget(p2, 1); l.addLayout(row)
        p3, p3l = panel("ตัวอย่าง Timeline", "แถบด้านล่างเป็นตัวอย่างตำแหน่ง ไม่ใช่เสียงที่สร้างแล้ว")
        for name, color, text in [("Original", "#315d9b", "ต้นฉบับ  00:01–00:10"), ("Thai voice", "#287b59", "เสียงไทย  00:01–00:10"), ("Thai subtitle", "#6749a8", "ซับไทย  00:01–00:10")]:
            line = QHBoxLayout(); line.addWidget(label(name, "muted"))
            bar = QLabel(text); bar.setStyleSheet(f"background:{color}; color:white; padding:9px; border-radius:6px;")
            line.addWidget(bar, 1); p3l.addLayout(line)
        l.addWidget(p3)
        btns = QHBoxLayout(); btns.addStretch()
        nxt = QPushButton("ไปหน้าส่งออก  →"); nxt.setObjectName("primary"); nxt.clicked.connect(lambda: self.navigate(4))
        btns.addWidget(nxt); l.addLayout(btns)
        return w

    def build_export(self):
        w, l = self.page_shell("Render / Output", "ส่งออกวิดีโอภาษาไทย", "กำหนดไฟล์ผลลัพธ์และตรวจสอบก่อน Render")
        row = QHBoxLayout()
        p, pl = panel("รูปแบบผลลัพธ์")
        self.container = QComboBox(); self.container.addItems(["MP4 • H.264 + AAC", "MKV • H.264 + AAC"])
        self.resolution = QComboBox(); self.resolution.addItems(["ความละเอียดเท่าต้นฉบับ", "1080p", "720p"])
        self.sub_export = QCheckBox("ฝังซับไทยในวิดีโอ"); self.sub_export.setChecked(True)
        self.audio_export = QCheckBox("ส่งออกไฟล์เสียงพากย์ WAV"); self.audio_export.setChecked(True)
        self.srt_export = QCheckBox("ส่งออกไฟล์ซับ SRT"); self.srt_export.setChecked(True)
        for t, widget in [("Container / Codec", self.container), ("ความละเอียด", self.resolution)]:
            pl.addWidget(label(t, "muted")); pl.addWidget(widget)
        pl.addWidget(self.sub_export); pl.addWidget(self.audio_export); pl.addWidget(self.srt_export)
        p2, p2l = panel("ตรวจสอบก่อนส่งออก")
        for t in ["☑ ตรวจสอบเสียงไม่ทับกัน", "☑ ตรวจสอบซับไม่เกินขอบจอ", "☑ ตรวจสอบความยาวเสียงกับวิดีโอ", "☑ เก็บไฟล์ต้นฉบับแยกไว้"]:
            p2l.addWidget(label(t))
        row.addWidget(p, 1); row.addWidget(p2, 1); l.addLayout(row)
        p3, p3l = panel("สถานะการ Render")
        self.progress = QProgressBar(); self.progress.setValue(0)
        self.status = label("ยังไม่ได้เริ่ม Render", "muted")
        p3l.addWidget(self.progress); p3l.addWidget(self.status)
        start = QPushButton("จำลองการ Render"); start.setObjectName("primary")
        start.clicked.connect(self.fake_render)
        p3l.addWidget(start); l.addWidget(p3)
        l.addStretch()
        return w

    def fake_render(self):
        self.progress.setValue(100)
        self.status.setText("Prototype: จำลองขั้นตอนสำเร็จ — ยังไม่ได้สร้างไฟล์วิดีโอจริง")
        QMessageBox.information(self, "Prototype", "นี่เป็นการจำลองหน้าจอเท่านั้น ยังไม่ได้เชื่อมต่อ AI, TTS หรือ FFmpeg")

    def build_demo(self):
        w, l = self.page_shell("Demo / Test Cases", "ทดลองภาษาอังกฤษและญี่ปุ่น", "ใช้ชุดประโยคตัวอย่างเพื่อทดสอบ workflow ก่อนเชื่อมต่อโมเดล AI จริง")
        row = QHBoxLayout()
        en, el = panel("DEMO 01 • English", "Input: English dialogue")
        el.addWidget(label("What are you doing?"))
        el.addWidget(label("Don't come closer!"))
        el.addWidget(label("I will protect you."))
        el.addWidget(label("Expected: Thai subtitle + Thai dubbing", "muted"))
        jp, jl = panel("DEMO 02 • Japanese", "Input: Japanese dialogue")
        jl.addWidget(label("何をしているの？"))
        jl.addWidget(label("近づかないで！"))
        jl.addWidget(label("私が守るよ。"))
        jl.addWidget(label("Expected: Thai subtitle + Thai dubbing", "muted"))
        row.addWidget(en); row.addWidget(jp); l.addLayout(row)
        p, pl = panel("ผลลัพธ์ที่ต้องตรวจ")
        for t in ["1. คำพูดที่ถอดได้ตรงกับเสียง", "2. แยกผู้พูดได้ถูกต้อง", "3. คำแปลไทยเป็นธรรมชาติ", "4. น้ำเสียงไทยสอดคล้องกับอารมณ์", "5. เสียงพากย์อยู่ในช่วงเวลาที่ถูกต้อง"]:
            pl.addWidget(label(t))
        l.addWidget(p); l.addStretch()
        return w

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyleSheet(APP_STYLE)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())

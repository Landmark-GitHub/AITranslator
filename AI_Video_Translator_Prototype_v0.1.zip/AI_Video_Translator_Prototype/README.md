# AI Video Translator Studio — Prototype v0.1

ต้นแบบหน้าจอโปรแกรม Windows สำหรับ workflow:
นำเข้าคลิป → วิเคราะห์คำพูด/ซับ → แปลไทย → ตั้งค่าเสียงพากย์ → Sync timeline → ส่งออก

## ขอบเขตเวอร์ชันนี้
- เป็น UI prototype ที่กดเปลี่ยนหน้าจอและทดลอง workflow ได้
- มีหน้าจอรองรับคลิปมีซับ/ไม่มีซับ, วิเคราะห์, แปล, เสียงพากย์, timeline, export และ Demo English/Japanese
- ยังไม่ได้เชื่อมต่อ Whisper, OCR, speaker diarization, translation model, TTS หรือ FFmpeg
- ปุ่ม Render เป็นการจำลองสถานะเท่านั้น ไม่ได้สร้าง MP4 จริง

## ต้องมี
- Windows 10/11
- Python 3.10 หรือใหม่กว่า
- PySide6

## ติดตั้งและเปิดโปรแกรม
```bash
py -m venv .venv
.venv\Scripts\activate
pip install PySide6
python main.py
```

## สร้างไฟล์ EXE
```bash
pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed --name AI_Video_Translator main.py
```
ไฟล์ EXE จะอยู่ในโฟลเดอร์ `dist`.

## สถาปัตยกรรมที่แนะนำสำหรับรุ่นถัดไป
- Local: FFmpeg, faster-whisper, OCR, audio preprocessing
- Cloud: translation, emotion/voice analysis และ Thai TTS ตามผู้ให้บริการที่เลือก
- Hybrid orchestration: เก็บ timestamps และผลตรวจใน project workspace; ให้ผู้ใช้ตรวจแก้ก่อน render
- Voice similarity: จับคู่โทน/อารมณ์/จังหวะด้วยเสียงสังเคราะห์ที่ได้รับอนุญาต ไม่โคลนเสียงบุคคลโดยไม่มีความยินยอม

@echo off
cd /d "%~dp0"
call .venv\Scripts\activate
pip install pyinstaller
pyinstaller --noconfirm --clean --windowed --name "AI Video Translator" ^
  --add-data "app;app" ^
  --add-data "resources;resources" ^
  main.py
echo.
echo Build complete. Check the dist folder.
pause

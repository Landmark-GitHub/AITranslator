import sys
from PySide6.QtWidgets import QApplication
from app.ui.main_window import MainWindow
from app.ui.styles import APP_STYLE

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AI Video Translator")
    app.setStyleSheet(APP_STYLE)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()

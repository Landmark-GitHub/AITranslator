APP_STYLE = """
QMainWindow, QDialog { background: #17191f; color: #f2f3f5; }
QWidget { color: #f2f3f5; font-family: Segoe UI; font-size: 10pt; }
QLabel#muted { color: #a5aab5; }
QFrame#panel { background: #222630; border: 1px solid #343a48; border-radius: 10px; }
QPushButton {
  background: #303747; border: 1px solid #414b60; border-radius: 7px;
  padding: 9px 14px; color: #ffffff;
}
QPushButton:hover { background: #3a465b; }
QPushButton#primary { background: #2867c7; border: 0; font-weight: 600; }
QPushButton#primary:hover { background: #3479df; }
QLineEdit, QComboBox {
  background: #202530; border: 1px solid #3a4251; border-radius: 6px;
  padding: 8px;
}
QListWidget { background: #202530; border: 1px solid #343a48; border-radius: 7px; }
QProgressBar { background: #303747; border: 0; border-radius: 5px; height: 10px; }
QProgressBar::chunk { background: #3479df; border-radius: 5px; }
QStatusBar { background: #202530; color: #a5aab5; }
"""

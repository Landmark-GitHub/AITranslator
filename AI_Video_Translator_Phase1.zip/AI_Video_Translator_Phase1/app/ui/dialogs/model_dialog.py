from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QListWidget, QPushButton

class ModelDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Model Manager")
        self.setMinimumSize(480, 360)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("รายการโมเดลที่เตรียมรองรับ"))
        self.list = QListWidget()
        self.list.addItems([
            "Speech Recognition — faster-whisper (Phase 2)",
            "Word Alignment — WhisperX / alignment model (Phase 2)",
            "Speaker Diarization — pyannote (Phase 2–3)",
            "Emotion Analysis — emotion2vec (Phase 3)",
            "Thai Translation — local translation model (Phase 4)",
            "Voice Cloning — cross-language model (Phase 4)",
            "Voice Cloning — reference voice model (Phase 4)",
        ])
        layout.addWidget(self.list)
        note = QLabel("Phase 1 ยังไม่ดาวน์โหลดโมเดล เพื่อให้ตรวจสอบ License, VRAM และ dependency ก่อน")
        note.setWordWrap(True)
        note.setObjectName("muted")
        layout.addWidget(note)
        close = QPushButton("ปิด")
        close.clicked.connect(self.accept)
        layout.addWidget(close)

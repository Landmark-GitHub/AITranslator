from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QHBoxLayout, QMessageBox
)
from app.config import SUPPORTED_VIDEO
from app.core.video_manager import inspect_video

class ImportDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Import Video")
        self.setMinimumWidth(520)
        self.video_info = None

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("เลือกวิดีโอสำหรับสร้างโปรเจกต์"))
        row = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("เลือกไฟล์ MP4 / MKV / MOV / AVI")
        browse = QPushButton("Browse")
        browse.clicked.connect(self.browse_file)
        row.addWidget(self.path_edit)
        row.addWidget(browse)
        layout.addLayout(row)

        self.info_label = QLabel("ยังไม่ได้เลือกไฟล์")
        self.info_label.setObjectName("muted")
        self.info_label.setWordWrap(True)
        layout.addWidget(self.info_label)

        buttons = QHBoxLayout()
        buttons.addStretch()
        cancel = QPushButton("ยกเลิก")
        cancel.clicked.connect(self.reject)
        self.ok_button = QPushButton("นำเข้าวิดีโอ")
        self.ok_button.setObjectName("primary")
        self.ok_button.clicked.connect(self.accept_if_valid)
        buttons.addWidget(cancel)
        buttons.addWidget(self.ok_button)
        layout.addLayout(buttons)

    def browse_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "เลือกวิดีโอ", "",
            "Video Files (*.mp4 *.mkv *.mov *.avi *.webm)"
        )
        if not path:
            return
        if not any(path.lower().endswith(ext) for ext in SUPPORTED_VIDEO):
            QMessageBox.warning(self, "ไฟล์ไม่รองรับ", "กรุณาเลือกไฟล์วิดีโอที่รองรับ")
            return
        try:
            self.video_info = inspect_video(path)
            self.path_edit.setText(path)
            v = self.video_info
            self.info_label.setText(
                f"{v['name']}\\n{v['width']} × {v['height']} | "
                f"{v['fps']} FPS | {v['duration_display']} นาที:วินาที"
            )
        except Exception as exc:
            self.video_info = None
            QMessageBox.critical(self, "อ่านวิดีโอไม่สำเร็จ", str(exc))

    def accept_if_valid(self):
        if not self.video_info:
            QMessageBox.information(self, "ยังไม่มีวิดีโอ", "กรุณาเลือกวิดีโอก่อน")
            return
        self.accept()

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QComboBox, QCheckBox,
    QPushButton, QHBoxLayout, QLabel
)

class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Project Settings")
        self.setMinimumWidth(420)
        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.source_language = QComboBox()
        self.source_language.addItems(["Auto Detect", "English", "Japanese"])
        self.target_language = QComboBox()
        self.target_language.addItem("Thai")
        self.clone_mode = QComboBox()
        self.clone_mode.addItems([
            "Both: Cross-language + Reference Voice",
            "Cross-language voice cloning",
            "Reference voice cloning",
        ])
        self.export_mp4 = QCheckBox("Export MP4")
        self.export_mp4.setChecked(True)
        self.export_srt = QCheckBox("Export SRT")
        self.export_srt.setChecked(True)

        form.addRow("Source language", self.source_language)
        form.addRow("Target language", self.target_language)
        form.addRow("Voice cloning", self.clone_mode)
        form.addRow("Output", self.export_mp4)
        form.addRow("", self.export_srt)
        layout.addLayout(form)

        note = QLabel("การตั้งค่านี้เป็นค่าโปรเจกต์เบื้องต้น โมเดล AI จะเชื่อมต่อใน Phase 2–4")
        note.setWordWrap(True)
        note.setObjectName("muted")
        layout.addWidget(note)

        buttons = QHBoxLayout()
        buttons.addStretch()
        close = QPushButton("ปิด")
        close.clicked.connect(self.accept)
        buttons.addWidget(close)
        layout.addLayout(buttons)

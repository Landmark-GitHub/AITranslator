from pathlib import Path
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFileDialog, QMessageBox, QFrame, QGridLayout,
    QStatusBar
)
from app.config import ensure_directories, APP_VERSION, OUTPUT_DIR
from app.core.hardware import get_hardware_info
from app.core.project_manager import create_project
from app.ui.dialogs.import_dialog import ImportDialog
from app.ui.dialogs.settings_dialog import SettingsDialog
from app.ui.dialogs.model_dialog import ModelDialog

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        ensure_directories()
        self.setWindowTitle(f"AI Video Translator — v{APP_VERSION}")
        self.resize(1180, 760)
        self.current_project = None
        self.current_video = None
        self._build_ui()
        self.refresh_hardware()

    def _panel(self):
        frame = QFrame()
        frame.setObjectName("panel")
        return frame

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(20, 18, 20, 16)
        root.setSpacing(14)

        header = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("AI Video Translator")
        title.setStyleSheet("font-size: 23pt; font-weight: 700;")
        subtitle = QLabel("Local AI • English / Japanese → Thai")
        subtitle.setObjectName("muted")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header.addLayout(title_box)
        header.addStretch()
        import_btn = QPushButton("＋  Import Video")
        import_btn.setObjectName("primary")
        import_btn.clicked.connect(self.import_video)
        header.addWidget(import_btn)
        root.addLayout(header)

        grid = QGridLayout()
        grid.setSpacing(14)

        preview = self._panel()
        pv = QVBoxLayout(preview)
        pv.addWidget(QLabel("VIDEO PREVIEW"))
        self.preview_label = QLabel("ยังไม่มีวิดีโอ\\n\\nกด Import Video เพื่อเริ่มโปรเจกต์")
        self.preview_label.setAlignment(__import__("PySide6").QtCore.Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setMinimumHeight(300)
        self.preview_label.setStyleSheet("background:#11141a; border-radius:8px; color:#9da5b4;")
        pv.addWidget(self.preview_label, 1)
        self.video_meta = QLabel("No video loaded")
        self.video_meta.setObjectName("muted")
        pv.addWidget(self.video_meta)
        grid.addWidget(preview, 0, 0, 2, 2)

        hardware = self._panel()
        hv = QVBoxLayout(hardware)
        hv.addWidget(QLabel("HARDWARE STATUS"))
        self.hardware_label = QLabel("กำลังตรวจสอบ...")
        self.hardware_label.setWordWrap(True)
        hv.addWidget(self.hardware_label)
        refresh = QPushButton("Refresh Hardware")
        refresh.clicked.connect(self.refresh_hardware)
        hv.addWidget(refresh)
        grid.addWidget(hardware, 0, 2)

        actions = self._panel()
        av = QVBoxLayout(actions)
        av.addWidget(QLabel("PROJECT TOOLS"))
        for label, callback in [
            ("Project Settings", self.open_settings),
            ("Model Manager", self.open_models),
            ("Open Output Folder", self.open_output),
        ]:
            btn = QPushButton(label)
            btn.clicked.connect(callback)
            av.addWidget(btn)
        av.addStretch()
        grid.addWidget(actions, 1, 2)
        root.addLayout(grid, 1)

        pipeline = self._panel()
        pl = QVBoxLayout(pipeline)
        pl.addWidget(QLabel("WORKFLOW"))
        stages = QHBoxLayout()
        for text in ["1 Import", "2 Speech", "3 Characters", "4 Translate", "5 Voice Clone", "6 Sync", "7 Export"]:
            item = QLabel(text)
            item.setAlignment(__import__("PySide6").QtCore.Qt.AlignmentFlag.AlignCenter)
            item.setStyleSheet("background:#303747; border-radius:6px; padding:10px 5px;")
            stages.addWidget(item)
        pl.addLayout(stages)
        self.project_label = QLabel("Project: ยังไม่ได้สร้างโปรเจกต์")
        self.project_label.setObjectName("muted")
        pl.addWidget(self.project_label)
        root.addWidget(pipeline)

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Ready — Phase 1 Foundation")

    def refresh_hardware(self):
        info = get_hardware_info()
        gpu_mem = f"{info['vram_gb']} GB" if info["vram_gb"] else "Unknown"
        self.hardware_label.setText(
            f"OS: {info['os']}\\n"
            f"CPU: {info['cpu']}\\n"
            f"RAM: {info['ram_total_gb']} GB total / {info['ram_available_gb']} GB free\\n"
            f"GPU: {info['gpu']}\\n"
            f"VRAM: {gpu_mem}\\n"
            f"CUDA: {info['cuda']}\\n"
            f"FFmpeg: {info['ffmpeg']}"
        )

    def import_video(self):
        dialog = ImportDialog(self)
        if dialog.exec():
            info = dialog.video_info
            self.current_video = info["path"]
            project_name = Path(info["path"]).stem
            try:
                self.current_project = create_project(project_name, self.current_video)
            except Exception as exc:
                QMessageBox.critical(self, "สร้างโปรเจกต์ไม่สำเร็จ", str(exc))
                return
            self.preview_label.setText(
                f"{info['name']}\\n\\n"
                f"{info['width']} × {info['height']}\\n"
                f"{info['duration_display']} | {info['fps']} FPS\\n\\n"
                "Phase 1: Metadata Preview"
            )
            self.video_meta.setText(f"{info['format']} • {info['frames']:,} frames")
            self.project_label.setText(f"Project: {self.current_project.name}")
            self.statusBar().showMessage("นำเข้าวิดีโอและสร้างโปรเจกต์แล้ว")

    def open_settings(self):
        SettingsDialog(self).exec()

    def open_models(self):
        ModelDialog(self).exec()

    def open_output(self):
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        import os
        os.startfile(str(OUTPUT_DIR))

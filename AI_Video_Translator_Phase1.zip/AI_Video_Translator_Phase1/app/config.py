from pathlib import Path

APP_NAME = "AI Video Translator"
APP_VERSION = "0.1.0"

BASE_DIR = Path(__file__).resolve().parent.parent
PROJECTS_DIR = BASE_DIR / "Projects"
MODELS_DIR = BASE_DIR / "Models"
VOICE_PROFILES_DIR = BASE_DIR / "VoiceProfiles"
OUTPUT_DIR = BASE_DIR / "Output"
CACHE_DIR = BASE_DIR / "Cache"
LOGS_DIR = BASE_DIR / "Logs"

SUPPORTED_VIDEO = {".mp4", ".mkv", ".mov", ".avi", ".webm"}

def ensure_directories():
    for path in (
        PROJECTS_DIR, MODELS_DIR, VOICE_PROFILES_DIR,
        OUTPUT_DIR, CACHE_DIR, LOGS_DIR,
        MODELS_DIR / "Whisper",
        MODELS_DIR / "Translation",
        MODELS_DIR / "Diarization",
        MODELS_DIR / "Emotion",
        MODELS_DIR / "Voice_Cloning",
    ):
        path.mkdir(parents=True, exist_ok=True)

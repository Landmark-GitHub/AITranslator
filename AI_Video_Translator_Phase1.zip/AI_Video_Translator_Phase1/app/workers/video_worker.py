from PySide6.QtCore import QObject, Signal, Slot
from app.core.video_manager import inspect_video

class VideoInfoWorker(QObject):
    finished = Signal(dict)
    failed = Signal(str)

    def __init__(self, path):
        super().__init__()
        self.path = path

    @Slot()
    def run(self):
        try:
            self.finished.emit(inspect_video(self.path))
        except Exception as exc:
            self.failed.emit(str(exc))

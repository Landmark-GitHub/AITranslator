import json
import re
from datetime import datetime
from pathlib import Path
from app.config import PROJECTS_DIR

def safe_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9ก-๙_-]+", "_", name.strip())
    return cleaned.strip("_") or "Untitled_Project"

def create_project(name: str, video_path: str = "") -> Path:
    folder_name = f"{safe_name(name)}_{datetime.now():%Y%m%d_%H%M%S}"
    project_dir = PROJECTS_DIR / folder_name
    project_dir.mkdir(parents=True, exist_ok=False)
    data = {
        "project_name": name.strip() or "Untitled Project",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "source_video": video_path,
        "source_language": "auto",
        "target_language": "th",
        "voice_clone_mode": "cross_language_and_reference",
        "output": {"mp4": True, "srt": True},
        "segments": [],
        "speakers": [],
    }
    (project_dir / "project.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return project_dir

def load_project(project_file: str):
    path = Path(project_file)
    return json.loads(path.read_text(encoding="utf-8"))

import platform
import shutil
import psutil

def get_hardware_info():
    info = {
        "os": platform.platform(),
        "cpu": platform.processor() or "Unknown",
        "ram_total_gb": round(psutil.virtual_memory().total / (1024 ** 3), 1),
        "ram_available_gb": round(psutil.virtual_memory().available / (1024 ** 3), 1),
        "gpu": "Not detected",
        "vram_gb": None,
        "cuda": "Not checked",
        "ffmpeg": shutil.which("ffmpeg") or "Not found",
    }

    try:
        import torch
        if torch.cuda.is_available():
            index = torch.cuda.current_device()
            props = torch.cuda.get_device_properties(index)
            info["gpu"] = props.name
            info["vram_gb"] = round(props.total_memory / (1024 ** 3), 1)
            info["cuda"] = torch.version.cuda or "Available"
        else:
            info["cuda"] = "PyTorch installed; CUDA unavailable"
    except ImportError:
        info["cuda"] = "PyTorch not installed"
    except Exception as exc:
        info["cuda"] = f"GPU check failed: {exc}"

    return info

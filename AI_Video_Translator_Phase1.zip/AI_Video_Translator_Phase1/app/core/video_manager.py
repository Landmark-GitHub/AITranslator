from pathlib import Path
import cv2

def inspect_video(file_path: str) -> dict:
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(file_path)

    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise ValueError("OpenCV ไม่สามารถเปิดไฟล์วิดีโอนี้ได้")

    fps = cap.get(cv2.CAP_PROP_FPS) or 0
    frames = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    cap.release()

    duration = frames / fps if fps > 0 else 0
    return {
        "name": path.name,
        "path": str(path.resolve()),
        "format": path.suffix.lower(),
        "width": width,
        "height": height,
        "fps": round(fps, 3),
        "frames": int(frames),
        "duration_seconds": round(duration, 2),
        "duration_display": f"{int(duration // 60):02d}:{int(duration % 60):02d}",
    }

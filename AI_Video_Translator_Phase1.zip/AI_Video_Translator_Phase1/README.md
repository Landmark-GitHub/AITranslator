# AI Video Translator — Phase 1

Windows desktop foundation for a local-first video translation and dubbing application.

## Requirements
- Windows 10 64-bit
- Python 3.11
- 16 GB RAM recommended
- NVIDIA GPU with 4–6 GB VRAM (GPU acceleration is optional in Phase 1)
- FFmpeg installed and available on PATH for media probing in later phases

## Run
1. Install Python 3.11.
2. Double-click `run.bat`, or run:
   - `py -3.11 -m venv .venv`
   - `.venv\\Scripts\\activate`
   - `pip install -r requirements.txt`
   - `python main.py`

## Phase 1 capabilities
- Desktop UI shell
- Import MP4/MKV/MOV/AVI
- Video metadata extraction with OpenCV
- Hardware information panel (CPU/RAM and optional NVIDIA/PyTorch detection)
- Project creation and JSON save
- Output and project folders
- Model Manager placeholder UI

## Not implemented yet
Speech recognition, diarization, emotion analysis, translation, voice cloning,
subtitle alignment, audio mixing, and final rendering are planned for later phases.

## Important
The EXE build in `build.bat` is a development build. PyTorch, FFmpeg binaries,
and AI model weights are not bundled. A production installer needs a separate
dependency and model packaging strategy. Voice cloning must only be used with
voices the user owns or is authorized to use.
